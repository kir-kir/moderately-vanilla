# Villager Retaliation! X Human Era: Villagers

This optional resource pack adapts Villager Retaliation's Humanoid Compatibility model to the 128x128 villager texture atlas used by Human Era Villagers & Illagers (HEVI).

It contains no HEVI textures, models, or artwork.

## Use

1. Install and enable HEVI normally.
2. Enable this bridge as a resource pack.
3. Set Villager Retaliation's `Villager Model Mode` config option to `Humanoid Compatibility`.
4. Reload resource packs or restart the client.

## Load order

Minecraft's resource-pack screen lists the highest-priority pack first. Use:

1. Villager Retaliation! X Human Era: Villagers
2. Human Era Villagers & Illagers (HEVI)
3. Fresh Animations (optional, for other entities)
4. Mod Resources
5. Default

Do not enable HEVI FreshAni Activator with this bridge.

Tested on Minecraft 1.21.1 with Villager Retaliation 1.0.0-beta.13 and HEVI 3.91.5.

Humanoid Compatibility keeps VR's independent-arm animations, held items, armor, player-shaped head, outer hat layer, and profession/type textures. It intentionally does not load HEVI's CEM geometry variants. Select `Pack Native` instead when exact HEVI/EMF geometry is more important than VR's armor and hand-held combat animations.

## Credits

See `CREDITS.txt` for the original Human Era credits bundled with this compatibility pack.
